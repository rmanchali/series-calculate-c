﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Gamesys
{
    public class SeriesCalculator: ISeriesCalculator 
    {
        private  const double ConstantValue = 3.14;
        public  List<double> GenerateNumber(double FirstNumber, double GrowthRate, double length)
        {
            List<double> Series = new List<double>();

            double CalcFirstNumber = CalculateFirstNumber(FirstNumber);
            double CalcGrowthRate = CalculateGrowthRate(CalcFirstNumber, GrowthRate);

            Series.Add(RoundingLogic(CalcFirstNumber));

            for (int i = 2; i <= length; i++)
            {
                Series.Add(RoundingLogic(CalculateNext(CalcFirstNumber, CalcGrowthRate, Series.Count)));
            }

            Series.Sort();
            return GetDistinct(Series);
        }

        private  double CalculateFirstNumber(double FirstNumber)
        {
            return ((0.5 * Math.Pow(FirstNumber, 2)) + (30 * FirstNumber) + 10) / 25;
        }

        private double CalculateGrowthRate(double FirstNumber, double GrowthRate)
        {
            //return ((0.5 * x ^ 2) + (30 * x) + 10) / 25;
            return ((GrowthRate * 2.0) / 100) / 25 / (FirstNumber);
        }

        private double CalculateNext(double FirstNumber, double GrowthRate, int index)
        {
        
            return GrowthRate * (Math.Pow(FirstNumber, index));
        }

        private double RoundingLogic(double NumberToRound)
        {
            return Math.Round(NumberToRound * 4, MidpointRounding.AwayFromZero) / 4;
        }

        private List<double> GetDistinct(List<double> UnSortedList)
        {

            return  UnSortedList.Distinct().ToList(); 
        }

        // could put thes two in a seperate class as this is different responsibility..
        public double GetHighestSequence(List<double> SortedList, int SequenceNumber)
        {
            // as this is a sorted list, the third highest will be the third number. Alternatively have to loop
            
            if (SortedList.Count >= SequenceNumber)
                return SortedList[SortedList.Count - SequenceNumber];
            else
                return 0;
        }

        public double GetSecondNumberSequence (List<double> SortedList, double input)
        {
            double multiply = input * ConstantValue;
            double ClosestValue=0;

            foreach (double value in SortedList)
            {
                if (ClosestValue == 0)
                    ClosestValue=value;
                else if(Math.Abs(value - multiply) <= Math.Abs(ClosestValue - multiply))
                    ClosestValue = value;
            }

            return  ClosestValue;
        
        }
    }
}
