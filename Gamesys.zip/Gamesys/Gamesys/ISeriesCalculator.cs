﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gamesys
{
     interface ISeriesCalculator
    {
        List<double> GenerateNumber(double FirstNumber, double GrowthRate, double length);
        double GetHighestSequence(List<double> SortedList, int SequenceNumber);
        double GetSecondNumberSequence(List<double> SortedList, double input);
    }
}
