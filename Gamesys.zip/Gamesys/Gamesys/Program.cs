﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gamesys
{
    class Program
    {
        private static  readonly int  SpecialSequenceNumber =3;
        

        static void Main(string[] args)
        {
            // add reference to interface rather than below concrete implementation. Apply dependency injection for this.
            
            SeriesCalculator calculator = new SeriesCalculator();
            List<double> series =  calculator.GenerateNumber(1, 5062.5, 5);
            double number1 = 0;
            double number2 = 0; 

            foreach( double value in series)
            {
                Console.WriteLine(value);
            }

            // as this is a sorted list, the third highest will be the third number. Alternatively have to loop
            number1 = calculator.GetHighestSequence(series, SpecialSequenceNumber);

            if (number1 == 0)
            {
                Console.WriteLine("Invalid Input");
            }
            else
            {
                Console.WriteLine("Number that is third Highest in the sequence: " +  number1.ToString());
            }


            number2 = calculator.GetSecondNumberSequence(series, 5);
            if (number2 == 0)
            {
                Console.WriteLine("Invalid Input");
            }
            else
            {
                Console.WriteLine("Number closest to :  " + number2.ToString());
            }


        }


        
    }
}
