﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Gamesys.Test
{
    [TestFixture]
    class UnitTests
    {
        // could make these parameterized to run with different values
        [TestCase]
        public void SeriesGenerator()
        {
            SeriesCalculator calculator = new SeriesCalculator();
            List<double> Series = calculator.GenerateNumber(1, 5062.5, 5);
            Assert.AreEqual(1.5, Series[0]);
            Assert.AreEqual(4, Series[1]);
            Assert.AreEqual(6.5, Series[2]);
            Assert.AreEqual(10.75, Series[3]);
            Assert.AreEqual(17.25, Series[4]);
        }

        [TestCase]
        public void GetThirdHighest()
        {
            SeriesCalculator calculator = new SeriesCalculator();
            List<double> Series = new List<double>();
            // should create something to add during compile time
            Series.Add(3.14);
            Series.Add(5.5);
            Series.Add(7);
            Series.Add(8.5);
            Series.Add(10);

            double ThirdHighest = calculator.GetHighestSequence(Series, 3);
            Assert.AreEqual(7, ThirdHighest);
            
        }


        [TestCase]
        public void getNumber2()
        {
            SeriesCalculator calculator = new SeriesCalculator();
            List<double> Series = new List<double>();
            // could make this better something to add during compile time
            Series.Add(3.14);
            Series.Add(5.5);
            Series.Add(7);
            Series.Add(8.5);
            Series.Add(10);

            double closest = calculator.GetSecondNumberSequence(Series, 2);
            Assert.AreEqual(7, closest);

        }

    }
}
